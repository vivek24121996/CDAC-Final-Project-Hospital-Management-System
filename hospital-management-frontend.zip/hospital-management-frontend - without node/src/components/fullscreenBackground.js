import { div, Image } from "react-bootstrap"

import "./full.css"
import img2 from "../assets/corosole2.jpeg"
const FullScreen=()=>{

    return(
        <div className="full" fluid >
            <div  >Hello</div>
            <Image ></Image>
        </div>
    )
}
export default FullScreen