package com.hms.custom_exception;

public class NoSuchPatientFoundException extends RuntimeException {

	

	public NoSuchPatientFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	

	

}
