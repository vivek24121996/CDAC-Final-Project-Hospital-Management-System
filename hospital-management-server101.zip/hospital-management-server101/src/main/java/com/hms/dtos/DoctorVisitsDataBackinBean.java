package com.hms.dtos;
import lombok.Data;
@Data
public class DoctorVisitsDataBackinBean {
		private int visitId;
		private int patientId;
		private int doctorId;
		private int visits;
		
}
